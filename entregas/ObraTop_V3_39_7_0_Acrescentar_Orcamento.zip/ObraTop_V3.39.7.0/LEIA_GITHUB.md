# Publicação automática (GitHub → Firebase Hosting)
1. Abra https://github.com/Raydem1961/obratop-bases/tree/main/entregas
2. Add file → Upload files → arraste o ZIP da nova versão → Commit changes.
3. Aba Actions: o fluxo "Publicar ObraTop" publica no Firebase (≈2 min).
4. No ObraTop, o aplicativo se atualiza sozinho (ou clique em "Atualizar aplicativo").
Chave de acesso: segredo FIREBASE_SERVICE_ACCOUNT do repositório (conta de serviço gh-deploy).

# Bases oficiais (robô diário)
- 3.39.7: leitor do SINAPI para o layout real (Relatórios a partir de 2025): gera 54 bases por mês (27 UF × desonerado/não desonerado × insumos+composições).
- Entrada: robô baixa do site da CAIXA; se o site recusar o robô, ele lê o ZIP colocado na pasta `fontes/` do repositório (SINAPI-AAAA-MM-formato-xlsx.zip).
- Mantém as 6 referências mais recentes por fonte. SICRO e ORSE ainda dependem de arquivo de exemplo.
