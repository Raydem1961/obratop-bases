// ObraTop 3.22.0 — automação gratuita
// Usuário do GitHub configurado: Raydem1961 (repositório obratop-bases).
window.OBRATOP_COST_BASES_CATALOG_URL =
  'https://raw.githubusercontent.com/Raydem1961/obratop-bases/main/docs/catalog.json';
window.OBRATOP_COST_BASES_REPO_URL =
  'https://github.com/Raydem1961/obratop-bases';
